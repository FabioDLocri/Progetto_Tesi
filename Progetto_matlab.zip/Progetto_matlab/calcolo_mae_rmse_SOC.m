function [mae, rmse] = calcolo_mae_rmse_SOC(y_true, y_pred, t)
% calcolo_mae_rmse  Calcola MAE/RMSE per 4 canali con dati 4x1xN
%                   e disegna 4 grafici distinti in un'unica figura.
%
% INPUT:
%   y_true -> 4x1xN
%   y_pred -> 4x1xN
%   t      -> Nx1 (opzionale)
%
% OUTPUT:
%   mae  -> 1x4
%   rmse -> 1x4

    if ~isequal(size(y_true), size(y_pred))
        error('y_true e y_pred devono avere la stessa dimensione.');
    end

    if ndims(y_true) ~= 3 || size(y_true,1) ~= 4
        error('Aspettati dati con dimensione 4x1xN.');
    end

    % Converte da 4x1xN a Nx4
    y_true2 = squeeze(y_true);   % diventa 4xN
    y_pred2 = squeeze(y_pred);   % diventa 4xN
    y_true2 = y_true2.';         % Nx4
    y_pred2 = y_pred2.';         % Nx4

    err = y_true2 - y_pred2;

    % MAE/RMSE per canale
    mae = mean(abs(err), 1);
    rmse = sqrt(mean(err.^2, 1));

    % Stampa risultati
    fprintf('MAE  per SOC Cella:  '); fprintf('%.6f  ', mae); fprintf('\n');
    fprintf('RMSE per SOC Cella:  '); fprintf('%.6f  ', rmse); fprintf('\n');

    % Grafici (4 subplot)
    figure;
    for k = 1:4
        subplot(2,2,k);
        if nargin < 3 || isempty(t)
            plot(err(:,k), 'LineWidth', 1.2);
            xlabel('Campione');
            m = max(abs(err(:,k)));
            ylim([-1.1*m, 1.1*m]);
        else
            t = t(:);
            if size(err,1) ~= numel(t)
                error('t deve avere la stessa lunghezza dei segnali (campioni).');
            end
            plot(t, err(:,k), 'LineWidth', 1.2);
            xlabel('Tempo [s]');
            m = max(abs(err(:,k)));
            ylim([-1.1*m, 1.1*m]);
        end
        grid on;
        ylabel(sprintf('Errore SOC %d', k));
        title(sprintf('Cella %d: MAE=%.4f, RMSE=%.4f', k, mae(k), rmse(k)));
    end
end